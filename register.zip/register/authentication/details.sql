-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 15, 2018 at 06:57 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `authentication`
--

-- --------------------------------------------------------

--
-- Table structure for table `details`
--

CREATE TABLE `details` (
  `ID` int(11) NOT NULL,
  `Shop_Name` varchar(250) NOT NULL,
  `Shop_Address` varchar(250) NOT NULL,
  `Phone_Number` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `details`
--

INSERT INTO `details` (`ID`, `Shop_Name`, `Shop_Address`, `Phone_Number`) VALUES
(1, 'TOP TEN', 'Sia Mosque, Ring Rd. Mohammadpur', 1951144290),
(2, 'Fit Elegance', 'Abul Mansur Akikunnesa Bhaban, 61B Rd No. 6A . Dhanmondi', 1721408267),
(3, 'Fit Elegance', 'Level-2, Plot- 1, Road- 3, Circle- 10, Sector- 6, Begum Rokeya Avenue.Mirpur', 1844165241),
(4, 'Fit Elegance', 'Shanta Western Tower, 186 Bir Uttam Mir Shawkat Sarak .Mohakhali', 28878747),
(5, 'Fit Elegance', 'House 116, B&B Empire, 2nd Floor, Rd No. 11.Gulshan', 1766141042),
(6, 'Top Ten Fabrics and Tailors Ltd', ' DIT II Cir .Gulshan ', 1618880533),
(7, 'TOP TEN', 'Gulshan Pink City Shopping Center, Gulshan Ave . Gulshan', 28881480),
(8, 'TOP TEN', ' Sumon Plaza, (1st Floor), Shop No. 183, Road Mirpur-10, Main Begum Rokeya Avenue . Mirpur', 1766350839),
(9, 'TOP TEN', 'Sonargaon Janapath . Uttara', 1952700957),
(10, 'TOP TEN', '5 Mirpur Rd . Mirpur', 29611569),
(11, 'Sunmoon Tailors Pvt. Ltd.', '#House 18 , #rd 6 , Dhanmondi Plaza . Dhanmondi', 1757050403),
(12, 'Moon Star Tailors & Fabrics', '18, 1st Floor, Dhanmondi Plaza, Road 6 . Dhanmondi ', 1710827314),
(13, 'Belmonte', '126/1 Elephant Road Bata Signal .Dhanmondi ', 29668993),
(14, 'The Raymond Shop', '1st Floor, Zahir AC Market, 52 New Elephant Rd .Dhanmondi', 29665710),
(15, ' Ibaadah Tailoring Shop', 'House- 20, Shop- 9, A.R.A Center, Road- 7, Dhanmondi', 1962653225);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `details`
--
ALTER TABLE `details`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `details`
--
ALTER TABLE `details`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
