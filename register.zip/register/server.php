<?php

session_start();

$username = "";
$email = "";
$errors = array();
 
 /// connect to the database 

$db = mysqli_connect('localhost','root','','registration');

   // if the register button is clicked 
   if(isset($_POST['register'])){
   	session_start();

   	$username = mysqli_real_escape_string($db,$_POST['username']);
   	$shop_name = mysqli_real_escape_string($db,$_POST['shop_name']);
   	$shop_address = mysqli_real_escape_string($db,$_POST['shop_address']);
   	$email = mysqli_real_escape_string($db,$_POST['email']);
   	$password_1 = mysqli_real_escape_string($db,$_POST['password_1']);
   	$password_2 = mysqli_real_escape_string($db,$_POST['password_2']);

       //ensure that form fields are filled properly 

       if(empty($username)){

       	array_push($errors,"Username is required"); // add error to errors
       } 

        if(empty($shop_name)){

       	array_push($errors,"Shop-name is required"); // add error to errors
       } 

        if(empty($shop_address)){

       	array_push($errors,"shop-address is required"); // add error to errors
       } 

        if(empty($email)){

       	array_push($errors,"email is required"); // add error to errors
       } 

        if(empty($password_1)){

       	array_push($errors,"password is required"); // add error to errors
       } 

        if($password_1 != $password_2) {

       	array_push($errors,"Password Mis-match"); // add error to errors
       
       } 
            
            // first check the database to make sure 
  // a user does not already exist with the same username and/or email

       $user_check_query = "SELECT * FROM users WHERE username = '$username'    

         OR email = '$email' LIMIT 1 ";

         if ($user) { // if user exists
    if ($user['username'] === $username) {
      array_push($errors, "Username already exists");
    }

    if ($user['email'] === $email) {
      array_push($errors, "email already exists");
    }
  }



  // if there are no errors , save user to database 


       if(count($errors)==0){

          $password_1 =md5($password_1);
         $sql = "INSERT INTO users (username,shop_name,shop_address,email,password_1) VALUES ('$username','$shop_name','$shop_address','$email','$password_1')";

         mysqli_query($db,$sql);

         
             $_SESSION['username'] =$username;
              $_SESSION['success'] = "you are now logged in ";
             header("location: home.php"); // redirect to home page 


       }
       
}  
//loguser 

if(isset($_POST['login'])){

	$username = mysqli_real_escape_string($db,$_POST['username']);
   	
   	$password = mysqli_real_escape_string($db,$_POST['password']);

       //ensure that form fields are filled properly 

       if(empty($username)){

       	array_push($errors,"Username is required"); // add error to errors
       } 

        if(empty($password)){

       	array_push($errors,"Password is required"); // add error to errors
       } 

       if(count($errors) == 0){

       	$password = md5($password);
       	$query = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
       	$result = mysqli_query($db,$query);
       	if (!$result || mysqli_num_rows($result) == 0){

       		// log user in 


       		 $_SESSION['username'] =$username;
              $_SESSION['success'] = "you are now logged in ";
             header("location: home.php"); // redirect to home page 
        }

        else 
        {

         array_push($errors,"wrong username /password combination");

}

}
       
}
              // logout 
       if(isset($_GET['logout'])){
        session_destroy();
       unset($_SESSION['username']);
       header('location:login.php');



}

?>